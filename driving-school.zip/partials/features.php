<section class="features py">
    <article class="title-section container">
        <h2>OUR FEATURES</h2>
    </article>
    <article class="container">
        <div class="wrapper">
            <div class="icon">
                <i class="fas fa-film"></i>
            </div>
            <h6>INSTRUCTIONAL VIDEO</h6>
            <p>Morbi efficitur tellus sapien, non feugiat ligula fringilla in. Morbi scelerisque placerat porta.
                Vivamus commodo consectetur commodo.</p>
        </div>

        <div class="wrapper">
            <div class="icon">
                <i class="fas fa-hand-point-right"></i>
            </div>
            <h6>DRIVING LESSONS</h6>
            <p>Morbi efficitur tellus sapien, non feugiat ligula fringilla in. Morbi scelerisque placerat porta.
                Vivamus commodo consectetur commodo.</p>
        </div>

        <div class="wrapper">
            <div class="icon">
                <i class="fas fa-car"></i>
            </div>
            <h6>DRIVER CONFIDENCE</h6>
            <p>Morbi efficitur tellus sapien, non feugiat ligula fringilla in. Morbi scelerisque placerat porta.
                Vivamus commodo consectetur commodo.</p>
        </div>

        <div class="wrapper">
            <div class="icon">
                <i class="fas fa-address-card"></i>
            </div>
            <h6>CERTIFIED</h6>
            <p>Morbi efficitur tellus sapien, non feugiat ligula fringilla in. Morbi scelerisque placerat porta.
                Vivamus commodo consectetur commodo.</p>
        </div>
    </article>
</section>