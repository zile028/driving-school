<h3>
    Categories
</h3>
<ul>
    <li><a href="#">Design/Build</a></li>
    <li><a href="#">General Construction</a> </li>
    <li><a href="#">Portable/Modular Buildings</a> </li>
    <li><a href="#">Construction Management</a> </li>
    <li><a href="#">Demolition</a> </li>
</ul>