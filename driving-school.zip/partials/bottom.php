<!-------- FOOTER -------->

<footer>
    <article class="container">
        <div>
            <a href="index.php"><img src="img/logo-02.png" alt=""></a>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore dolore debitis ullam cum magnam
                molestias nobis, voluptates temporibus accusantium corrupti recusandae sequi? Facilis qui asperiores
                voluptates molestiae illum earum quo.</p>
        </div>
        <div>
            <h3>links</h3>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="courses.php">Courses</a></li>
                <li><a href="teacher.php">Teachers</a></li>
                <li><a href="intro.php">About</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </div>
        <div>
            <h3>contact us</h3>
            <ul class="contact-footer p-t-28">
                <li>
                    <i class="fas fa-home" aria-hidden="true"></i>
                    379 5th Ave New York, NYC 10018
                </li>
                <li>
                    <i class="fas fa-phone" aria-hidden="true"></i>
                    (+1) 96 716 6879
                </li>
                <li>
                    <i class="fas fa-fax" aria-hidden="true"></i>
                    (+1) 96 716 6879
                </li>
                <li>
                    <i class="fas fa-envelope" aria-hidden="true"></i>
                    contact@site.com
                </li>
                <li>
                    <i class="fas fa-clock" aria-hidden="true"></i>
                    Mon-Fri 09:00 - 17:00
                </li>
            </ul>
        </div>
    </article>
    <article>
        <p class="s-txt10">@ 2018 AuThemes.</p>
    </article>
</footer>


</body>

</html>